# Sample archive

This little archive exists so the Archive Viewer has something to open on a
first visit. Everything in it is plain text.

Contents:
  README.md          this file
  data/notes.txt     a short note
  data/reading.csv   a few rows of numbers
  logs/app.log       a repetitive log, so compression has something to do
